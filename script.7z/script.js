// src/App.jsx - Enhanced visual styles and decorated UI // Requirements: Tailwind CSS in project

import React, { useEffect, useRef, useState } from "react";

const LOCAL_KEY = "gf_photos_v1"; function uid() { return Math.random().toString(36).slice(2,9); } async function fileToDataURL(file){ return new Promise((resolve, reject)=>{ const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=reject; r.readAsDataURL(file); }); }

export default function App(){ const [items,setItems]=useState([]); const [dragActive,setDragActive]=useState(false); const [modal,setModal]=useState(null); const [loading,setLoading]=useState(false); const [theme,setTheme]=useState("romantic"); // default romantic const [hearts,setHearts]=useState([]); const [loveOpen,setLoveOpen]=useState(false); const inputRef=useRef(null); const dropRef=useRef(null);

useEffect(()=>{ try{ window.history.replaceState(null, "Saida's Photos", "/saida"); document.title = "Saida's Photos"; }catch(e){} const onOpen=()=>setLoveOpen(true); window.addEventListener('openLove', onOpen); return ()=>window.removeEventListener('openLove', onOpen); },[]); useEffect(()=>{ try{ const raw=localStorage.getItem(LOCAL_KEY); if(raw) setItems(JSON.parse(raw)); }catch(e){ } },[]); useEffect(()=>{ try{ localStorage.setItem(LOCAL_KEY, JSON.stringify(items)); }catch(e){} },[items]);

useEffect(()=>{ const onDragOver=(e)=>{ e.preventDefault(); setDragActive(true); }; const onDragLeave=()=>setDragActive(false); const onDrop=(e)=>{ e.preventDefault(); setDragActive(false); const files=Array.from(e.dataTransfer.files||[]); if(files.length) handleFiles(files); }; window.addEventListener('dragover', onDragOver); window.addEventListener('dragleave', onDragLeave); window.addEventListener('drop', onDrop); return ()=>{ window.removeEventListener('dragover', onDragOver); window.removeEventListener('dragleave', onDragLeave); window.removeEventListener('drop', onDrop); }; },[]); useEffect(()=>{ if(!hearts.length) return; const t=setTimeout(()=>setHearts([]),1800); return ()=>clearTimeout(t); },[hearts]);

async function handleFiles(files){ setLoading(true); const accepted = files.filter(f=>/image|video/.test(f.type)); if(!accepted.length){ setLoading(false); alert('Only image and video files are accepted.'); return; } const newItems=[]; for(const f of accepted){ try{ const dataURL=await fileToDataURL(f); newItems.push({ id:uid(), name:f.name, type:f.type, dataURL, created:Date.now() }); }catch(e){ console.error(e); } } setItems(prev=>[...newItems,...prev]); setLoading(false); } function onInputChange(e){ const files = Array.from(e.target.files||[]); if(files.length) handleFiles(files); e.target.value=null; } function triggerFilePick(){ inputRef.current?.click(); } function removeItem(id){ if(!confirm('Delete this item?')) return; setItems(prev=>prev.filter(i=>i.id!==id)); if(modal===id) setModal(null); } function downloadItem(item){ const a=document.createElement('a'); a.href=item.dataURL; a.download=item.name||${item.id}; document.body.appendChild(a); a.click(); a.remove(); } function spawnHearts(clientX, clientY){ const count=8; const newHearts=Array.from({length:count}).map(()=>({ id:uid(), x:clientX + (Math.random()*80-40), y:clientY + (Math.random()*30-15), size:16 + Math.random()*20, hue: theme==='romantic'? 'pink' : (Math.random()>0.5?'cyan':'purple') })); setHearts(newHearts); } function handleItemClick(e,id){ const native = e && e.nativeEvent ? e.nativeEvent : e; const { clientX = window.innerWidth/2, clientY = window.innerHeight/2 } = native || {}; spawnHearts(clientX, clientY); setModal(id); }

const themeBg = { neon: 'bg-gradient-to-br from-slate-900 via-purple-900 to-black text-cyan-100', romantic: 'bg-gradient-to-br from-pink-50 via-rose-100 to-white text-rose-800', animated: 'bg-gradient-to-br from-indigo-600 via-violet-500 to-pink-500 text-white' }[theme]; const cardBase = 'rounded-2xl overflow-hidden shadow-2xl border border-white/20'; function itemStyle(){ if(theme==='neon') return { boxShadow:'0 10px 40px rgba(99,102,241,0.14)', border:'2px solid rgba(99,102,241,0.45)' }; if(theme==='romantic') return { boxShadow:'0 10px 40px rgba(236,72,153,0.10)', border:'1px solid rgba(255,182,193,0.5)' }; return { boxShadow:'0 10px 40px rgba(0,0,0,0.18)', border:'1px solid rgba(255,255,255,0.06)' }; }

return ( <div className={min-h-screen p-4 md:p-8 ${themeBg}}> <style>{@keyframes floatUp { 0%{ transform:translateY(0) scale(1); opacity:1 } 100%{ transform:translateY(-140px) scale(1.12); opacity:0 } } .heart-anim{ position:absolute; pointer-events:none; animation: floatUp 1.6s ease forwards; transform-origin:center; } .heart-shadow{ filter: drop-shadow(0 8px 18px rgba(0,0,0,0.25)); } /* modal entrance */ .modal-enter{ transform: translateY(18px) scale(.98); opacity:0 } .modal-enter-active{ transform: translateY(0) scale(1); opacity:1; transition: all 320ms cubic-bezier(.2,.9,.2,1); }}</style>

<div className="max-w-6xl mx-auto">
    {/* Header with decorative title */}
    <header className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-4">
        <div className="rounded-full w-14 h-14 flex items-center justify-center text-2xl" style={{ background: 'linear-gradient(135deg,#ff9bb3,#ff6ea6)', boxShadow:'0 6px 24px rgba(255,110,166,0.18)' }}>💖</div>
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Saida's Photos</h1>
          <div className="text-sm opacity-80">Teri yaadein, yahin safe — upload kar de, aur dekhte hi khush ho jaa.</div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 rounded-xl p-1 bg-white/6">
          <button onClick={()=>setTheme('neon')} className={`px-3 py-1 rounded-xl text-sm ${theme==='neon'?'bg-white/10 ring-2 ring-cyan-400':'opacity-80'}`}>Neon</button>
          <button onClick={()=>setTheme('romantic')} className={`px-3 py-1 rounded-xl text-sm ${theme==='romantic'?'bg-white/10 ring-2 ring-pink-300':'opacity-80'}`}>Romantic</button>
          <button onClick={()=>setTheme('animated')} className={`px-3 py-1 rounded-xl text-sm ${theme==='animated'?'bg-white/10 ring-2 ring-violet-300':'opacity-80'}`}>Animated</button>
        </div>

        <button onClick={()=>{ setItems([]); localStorage.removeItem(LOCAL_KEY); }} className="px-3 py-2 rounded-full bg-gradient-to-r from-red-400 to-pink-500 text-white shadow-lg">Clear all</button>
      </div>
    </header>

    {/* Upload area */}
    <section>
      <div ref={dropRef} onClick={triggerFilePick} className={`border-2 ${dragActive?'border-white/70 bg-white/6':'border-dashed border-white/30'} rounded-3xl p-6 text-center cursor-pointer transition-all duration-300`}>
        <input ref={inputRef} type="file" accept="image/*,video/*" multiple onChange={onInputChange} className="hidden" />
        <div className="flex items-center justify-center gap-4 flex-col md:flex-row md:gap-6">
          <div className="text-left">
            <strong className="text-lg">Click or drop photos & videos here</strong>
            <div className="text-sm opacity-80 mt-1">High quality images okay. Videos limited by browser storage — use backend for large files.</div>
            <div className="mt-3">
              <button onClick={triggerFilePick} className="px-5 py-2 rounded-full bg-gradient-to-r from-pink-400 to-yellow-300 text-white font-semibold shadow-xl transform hover:-translate-y-1 transition">Add media</button>
            </div>
          </div>

          <div className="hidden md:block">
            <div className="p-3 bg-white/6 rounded-lg">Tip: Click an image to open and send hearts ❤️</div>
          </div>
        </div>
      </div>
      {loading && <div className="mt-4 text-sm">Processing files…</div>}
    </section>

    {/* Gallery */}
    <section className="mt-6">
      <h2 className="text-lg font-semibold mb-3">Gallery ({items.length})</h2>
      {items.length===0? (
        <div className="text-sm opacity-80">No items yet — add some pictures or videos.</div>
      ):(
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
          {items.map(item=> (
            <div key={item.id} style={itemStyle()} className={`${cardBase} relative transform transition-all duration-300 hover:scale-105`}> 
              <button onClick={(e)=>handleItemClick(e,item.id)} className={`w-full h-44 flex items-center justify-center overflow-hidden relative group`}>
                {item.type.startsWith('image')? (
                  <img src={item.dataURL} alt={item.name} className={`object-cover w-full h-full transition-transform duration-500 ${theme==='animated'?'group-hover:scale-110 group-hover:rotate-1':''}`} />
                ):(
                  <video src={item.dataURL} className={`object-cover w-full h-full ${theme==='animated'?'group-hover:scale-105':''}`} muted />
                )}

                {theme==='neon' && <div className="pointer-events-none absolute inset-0 mix-blend-screen" style={{ boxShadow:'inset 0 0 40px rgba(99,102,241,0.08), 0 0 28px rgba(99,102,241,0.18)' }} />}
                {theme==='romantic' && <div className="pointer-events-none absolute right-2 top-2 text-2xl opacity-90 animate-pulse">❤</div>}

              </button>

              <div className="p-3 flex items-center justify-between gap-2">
                <div className="truncate text-sm opacity-90">{item.name}</div>
                <div className="flex items-center gap-2">
                  <button onClick={()=>downloadItem(item)} title="Download" className="text-xs px-2 py-1 rounded-full bg-white/8">DL</button>
                  <button onClick={()=>removeItem(item.id)} title="Delete" className="text-xs px-2 py-1 rounded-full bg-red-400/20">Del</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>

    {/* Modal */}
    {modal && (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60" onClick={()=>setModal(null)} />
        <div className="relative max-w-3xl w-full rounded-2xl overflow-hidden modal-enter modal-enter-active bg-white/5 border border-white/10 p-4">
          <div className="p-3 flex justify-between items-center bg-gradient-to-r from-white/4 to-white/2 rounded-xl">
            <div className="text-sm font-medium">{items.find(i=>i.id===modal)?.name}</div>
            <div className="flex items-center gap-2">
              <button onClick={()=>downloadItem(items.find(i=>i.id===modal))} className="px-2 py-1 rounded bg-white/8 text-sm">Download</button>
              <button onClick={()=>removeItem(modal)} className="px-2 py-1 rounded bg-red-400/20 text-sm">Delete</button>
              <button onClick={()=>setModal(null)} className="px-2 py-1 rounded bg-white/6 text-sm">Close</button>
            </div>
          </div>

          <div className="p-4 bg-white/6 flex justify-center rounded-xl mt-3">
            {items.find(i=>i.id===modal)?.type.startsWith('image')? (
              <img src={items.find(i=>i.id===modal).dataURL} alt="full" className="w-full max-h-[70vh] object-contain rounded-xl" />
            ):(
              <video src={items.find(i=>i.id===modal).dataURL} controls className="w-full max-h-[70vh] rounded-xl" />
            )}
          </div>
        </div>
      </div>
    )}

    {/* floating hearts overlay */}
    <div className="fixed inset-0 pointer-events-none">
      {hearts.map(h=> (
        <div key={h.id} className={`heart-anim heart-shadow`} style={{ left: h.x-12+'px', top: h.y-12+'px', fontSize: h.size+'px', color: h.hue==='pink' ? '#ff6ea6' : (h.hue==='cyan' ? '#7df9ff' : '#c084fc') }}>❤️</div>
      ))}
    </div>

    {/* Love letter floating button */}
    <div className="fixed z-60 right-6 bottom-6">
      <button id="love-btn" onClick={()=>{ window.dispatchEvent(new CustomEvent('openLove')); setLoveOpen(true); }} className="w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-2xl" style={{ background:'linear-gradient(135deg,#ff7ab6,#ffb3c6)', border:'2px solid rgba(255,255,255,0.6)' }} aria-label="Open love message">💌</button>
    </div>

    {/* Love message modal */}
    {loveOpen && (
      <div className="fixed inset-0 z-70 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/50" onClick={()=>setLoveOpen(false)} />
        <div className="relative max-w-md w-full bg-white/95 rounded-2xl p-6 shadow-2xl border border-pink-200 modal-enter modal-enter-active">
          <div className="flex items-start gap-3">
            <div className="text-4xl">💌</div>
            <div>
              <h3 className="text-lg font-bold">Saida ❤️</h3>
              <p className="mt-2 text-sm">Hey Saida! Tu meri fav ho — teri photo dekhte hi dil khush ho gaya. Jaldi mil le, bahut miss kar raha hun 😘</p>
              <p className="mt-2 text-sm opacity-80">— Tera pyaar (aur thoda sa drama)</p>
              <div className="mt-4 flex gap-2">
                <button onClick={()=>setLoveOpen(false)} className="px-3 py-1 rounded-md bg-pink-500 text-white">Close</button>
                <button onClick={()=>{ setLoveOpen(false); alert('Sent ❤️'); }} className="px-3 py-1 rounded-md bg-white border">Send ❤</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )}

    <div className="mt-8 text-sm opacity-80">Client-only demo • For a real site, add a backend to store files and user auth</div>
  </div>
</div>

); }